public class Musica {
    private String nome;
    private String album;

    public Musica(String nome, String album) {
        this.nome = nome;
        this.album = album;
    }

    public String getNome() {
        return nome;
    }

    public void imprimirMusica() {
        System.out.println("Música: " + nome + " | Álbum: " + album);
    }
}
